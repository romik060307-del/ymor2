# Upstream and third-party notices

Ymor is a modified derivative of **Metrolist** (MetrolistGroup), an open-source YouTube Music client. The supplied Metrolist source snapshot is retained as the code base for Ymor, and the original `LICENSE` file is preserved.

- Upstream project: https://github.com/MetrolistGroup/Metrolist
- License: GNU General Public License, version 3 (GPL-3.0)
- Ymor package/application ID: `app.ymor.music`
- Ymor-specific changes: branding, icon, default theme, glass-inspired floating navigation, player defaults, updater/crash-reporting defaults, and GitHub Actions build workflow.

The `com.metrolist` source namespaces and original GPL headers have intentionally been retained. This avoids breaking internal references and preserves required notices. Ymor's app name, icon, application ID, and visible interface branding are separate.

The project also uses external libraries and generated protocol/native source as declared in Gradle build files and `.gitmodules`. Their respective licenses remain applicable.
