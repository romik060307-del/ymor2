# Cara build APK Ymor di GitHub

Build berjalan **otomatis** setiap ada commit/upload baru ke branch utama (`main`/`master`).
Tidak perlu klik *Run workflow* (tombolnya tetap ada sebagai cadangan).

1. Buat repository baru di GitHub.
2. Upload isi proyek ini. Karena proyek berisi ribuan file, cara termudah lewat browser adalah
   membungkusnya jadi satu file `.zip` lalu upload zip itu bersama folder `.github`.
   Workflow akan membongkar zip-nya sendiri. Kalau memakai `git push`, push saja isi folder ini apa adanya.
3. Buka tab **Actions** dan tunggu run **Build Ymor APK** berubah jadi centang hijau
   (build pertama sekitar 20–60 menit).
4. Buka run tersebut, unduh artifact **Ymor-Android-APK**, ekstrak, lalu pasang `Ymor.apk` di HP.

Build ini menghasilkan APK *debug* yang sudah ditandatangani sehingga bisa dipasang untuk pengujian.
Kunci debug dibuat baru di tiap run, jadi kalau Android menolak karena "tanda tangan berbeda",
hapus (uninstall) versi Ymor yang lama dulu sebelum memasang yang baru.
Untuk distribusi dan update jangka panjang, siapkan satu keystore milik sendiri lalu simpan nilainya
sebagai GitHub Actions Secrets sebelum membuat build release.
