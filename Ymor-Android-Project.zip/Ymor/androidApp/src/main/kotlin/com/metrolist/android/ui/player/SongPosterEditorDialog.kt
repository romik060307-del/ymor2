/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.android.ui.player

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.SuccessResult
import coil3.toBitmap
import com.metrolist.shared.generated.resources.Res
import com.metrolist.shared.generated.resources.poster_card_opacity
import com.metrolist.shared.generated.resources.poster_card_size
import com.metrolist.shared.generated.resources.poster_choose_photo
import com.metrolist.shared.generated.resources.poster_effect_grain
import com.metrolist.shared.generated.resources.poster_effect_sparkle
import com.metrolist.shared.generated.resources.poster_effect_vignette
import com.metrolist.shared.generated.resources.poster_editor_title
import com.metrolist.shared.generated.resources.poster_fill_screen
import com.metrolist.shared.generated.resources.poster_fit_all
import com.metrolist.shared.generated.resources.poster_mirror
import com.metrolist.shared.generated.resources.poster_photo_horizontal
import com.metrolist.shared.generated.resources.poster_photo_size
import com.metrolist.shared.generated.resources.poster_photo_vertical
import com.metrolist.shared.generated.resources.poster_remove_photo
import com.metrolist.shared.generated.resources.poster_rendering
import com.metrolist.shared.generated.resources.poster_reset_all
import com.metrolist.shared.generated.resources.poster_reset_position
import com.metrolist.shared.generated.resources.poster_rotate
import com.metrolist.shared.generated.resources.poster_save
import com.metrolist.shared.generated.resources.poster_saved
import com.metrolist.shared.generated.resources.poster_save_failed
import com.metrolist.shared.generated.resources.poster_share
import com.metrolist.shared.generated.resources.poster_sticker_heart
import com.metrolist.shared.generated.resources.poster_sticker_music
import com.metrolist.shared.generated.resources.poster_sticker_star
import com.metrolist.shared.generated.resources.poster_style_dark
import com.metrolist.shared.generated.resources.poster_style_light
import com.metrolist.shared.generated.resources.poster_style_minimal
import com.metrolist.shared.generated.resources.poster_style_retro
import com.metrolist.shared.generated.resources.poster_tab_card
import com.metrolist.shared.generated.resources.poster_tab_card_style
import com.metrolist.shared.generated.resources.poster_tab_effects
import com.metrolist.shared.generated.resources.poster_tab_photo
import com.metrolist.shared.generated.resources.poster_tab_stickers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.compose.resources.stringResource
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private enum class PosterTab { PHOTO, CARD, STYLE, EFFECTS, STICKERS }
private enum class PosterCardStyle { MINIMAL, DARK, LIGHT, RETRO }
private enum class PosterFit { FILL, FIT }

@Composable
internal fun SongPosterEditorDialog(
    title: String,
    artist: String,
    artworkUrl: String?,
    lyrics: String,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val savedMessage = stringResource(Res.string.poster_saved)
    val failedMessage = stringResource(Res.string.poster_save_failed)
    val shareLabel = stringResource(Res.string.poster_share)

    var selectedTab by remember { mutableStateOf(PosterTab.PHOTO) }
    var backgroundUri by remember { mutableStateOf<Uri?>(null) }
    var photoScale by remember { mutableFloatStateOf(1f) }
    var photoOffsetX by remember { mutableFloatStateOf(0f) }
    var photoOffsetY by remember { mutableFloatStateOf(0f) }
    var photoRotation by remember { mutableFloatStateOf(0f) }
    var photoMirrored by remember { mutableStateOf(false) }
    var photoFit by remember { mutableStateOf(PosterFit.FILL) }
    var cardScale by remember { mutableFloatStateOf(1f) }
    var cardOpacity by remember { mutableFloatStateOf(0.92f) }
    var cardOffsetX by remember { mutableFloatStateOf(0f) }
    var cardOffsetY by remember { mutableFloatStateOf(0f) }
    var cardRotation by remember { mutableFloatStateOf(0f) }
    var previewSize by remember { mutableStateOf(IntSize.Zero) }
    var cardStyle by remember { mutableStateOf(PosterCardStyle.MINIMAL) }
    var vignetteEnabled by remember { mutableStateOf(true) }
    var sparkleEnabled by remember { mutableStateOf(false) }
    var grainEnabled by remember { mutableStateOf(false) }
    var selectedSticker by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pendingSave by remember { mutableStateOf(false) }

    val photoPicker =
        rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                backgroundUri = uri
                photoScale = 1f
                photoOffsetX = 0f
                photoOffsetY = 0f
                photoRotation = 0f
                photoMirrored = false
                photoFit = PosterFit.FILL
            }
        }

    val config =
        PosterRenderConfig(
            backgroundUri = backgroundUri,
            fallbackArtworkUrl = artworkUrl,
            title = title,
            artist = artist,
            lyrics = lyrics,
            photoScale = photoScale,
            photoOffsetX = photoOffsetX,
            photoOffsetY = photoOffsetY,
            photoRotation = photoRotation,
            photoMirrored = photoMirrored,
            photoFit = photoFit,
            cardScale = cardScale,
            cardOpacity = cardOpacity,
            cardOffsetX = if (previewSize.width > 0) cardOffsetX / previewSize.width else 0f,
            cardOffsetY = if (previewSize.height > 0) cardOffsetY / previewSize.height else 0f,
            cardRotation = cardRotation,
            cardStyle = cardStyle,
            vignetteEnabled = vignetteEnabled,
            sparkleEnabled = sparkleEnabled,
            grainEnabled = grainEnabled,
            sticker = selectedSticker,
        )

    fun exportPoster(saveToGallery: Boolean) {
        if (busy) return
        busy = true
        scope.launch {
            var renderedBitmap: Bitmap? = null
            try {
                val bitmap = renderSongPoster(context, config)
                renderedBitmap = bitmap
                if (saveToGallery) {
                    savePosterToGallery(context, bitmap)
                    Toast.makeText(context, savedMessage, Toast.LENGTH_LONG).show()
                } else {
                    sharePosterBitmap(context, bitmap, shareLabel)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                Toast.makeText(context, failedMessage, Toast.LENGTH_LONG).show()
            } finally {
                renderedBitmap?.let { if (!it.isRecycled) it.recycle() }
                busy = false
            }
        }
    }

    val storagePermissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) pendingSave = true else Toast.makeText(context, failedMessage, Toast.LENGTH_LONG).show()
        }

    LaunchedEffect(pendingSave) {
        if (pendingSave) {
            pendingSave = false
            exportPoster(saveToGallery = true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.96f).widthIn(max = 560.dp),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(Res.string.poster_editor_title),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    TextButton(onClick = {
                        photoScale = 1f
                        photoOffsetX = 0f
                        photoOffsetY = 0f
                        photoRotation = 0f
                        photoMirrored = false
                        photoFit = PosterFit.FILL
                        cardScale = 1f
                        cardOpacity = 0.92f
                        cardOffsetX = 0f
                        cardOffsetY = 0f
                        cardRotation = 0f
                        cardStyle = PosterCardStyle.MINIMAL
                        vignetteEnabled = true
                        sparkleEnabled = false
                        grainEnabled = false
                        selectedSticker = null
                    }) {
                        Text(stringResource(Res.string.poster_reset_all))
                    }
                }

                BoxWithConstraints(
                    modifier =
                        Modifier
                            .align(Alignment.CenterHorizontally)
                            .fillMaxWidth()
                            .widthIn(max = 290.dp)
                            .aspectRatio(9f / 16f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF20213A), Color(0xFF11111A)),
                                ),
                            ).onSizeChanged { previewSize = it },
                ) {
                    if (backgroundUri != null || !artworkUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = backgroundUri ?: artworkUrl,
                            contentDescription = null,
                            contentScale = if (photoFit == PosterFit.FILL) ContentScale.Crop else ContentScale.Fit,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = photoScale * if (photoMirrored) -1f else 1f
                                        scaleY = photoScale
                                        translationX = photoOffsetX / 100f * size.width
                                        translationY = photoOffsetY / 100f * size.height
                                        rotationZ = photoRotation
                                    },
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    0f to Color.Black.copy(alpha = 0.10f),
                                    0.52f to Color.Transparent,
                                    1f to Color.Black.copy(alpha = 0.64f),
                                ),
                            ),
                    )
                    if (sparkleEnabled) {
                        Text(
                            text = "✦       ✧\n    ✧       ✦",
                            modifier = Modifier.align(Alignment.TopEnd).padding(18.dp),
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.titleLarge,
                        )
                    }
                    if (vignetteEnabled) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        0.35f to Color.Transparent,
                                        1f to Color.Black.copy(alpha = 0.55f),
                                    ),
                                ),
                        )
                    }
                    Surface(
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .offset { IntOffset(cardOffsetX.roundToInt(), cardOffsetY.roundToInt()) }
                                .graphicsLayer {
                                    scaleX = cardScale
                                    scaleY = cardScale
                                    rotationZ = cardRotation
                                }.pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoomChange, rotationChange ->
                                        cardOffsetX += pan.x
                                        cardOffsetY += pan.y
                                        cardScale = (cardScale * zoomChange).coerceIn(0.55f, 1.65f)
                                        cardRotation = (cardRotation + rotationChange).coerceIn(-30f, 30f)
                                    }
                                },
                        shape = RoundedCornerShape(24.dp),
                        color = cardContainerColor(cardStyle).copy(alpha = cardOpacity),
                        contentColor = cardContentColor(cardStyle),
                        border = BorderStroke(1.dp, cardContentColor(cardStyle).copy(alpha = 0.16f)),
                        shadowElevation = 10.dp,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AsyncImage(
                                model = artworkUrl,
                                contentDescription = null,
                                modifier = Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)),
                                contentScale = ContentScale.Crop,
                            )
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, color = cardContentColor(cardStyle).copy(alpha = 0.72f))
                                if (lyrics.isNotBlank()) {
                                    Text(
                                        lyrics.lineSequence().firstOrNull().orEmpty(),
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        color = cardContentColor(cardStyle).copy(alpha = 0.78f),
                                    )
                                }
                                Box(
                                    Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(10.dp))
                                        .background(cardContentColor(cardStyle).copy(alpha = 0.20f)),
                                ) {
                                    Box(Modifier.fillMaxWidth(0.42f).fillMaxSize().background(cardContentColor(cardStyle)))
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("♫", style = MaterialTheme.typography.labelLarge)
                                    Text("Ⅱ", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text("↗", style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                    if (selectedSticker != null) {
                        Text(
                            text = selectedSticker.orEmpty(),
                            modifier = Modifier.align(Alignment.TopStart).padding(22.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.headlineLarge,
                        )
                    }
                    Text(
                        text = "YMOR",
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    PosterTab.values().forEach { tab ->
                        val label =
                            when (tab) {
                                PosterTab.PHOTO -> stringResource(Res.string.poster_tab_photo)
                                PosterTab.CARD -> stringResource(Res.string.poster_tab_card)
                                PosterTab.STYLE -> stringResource(Res.string.poster_tab_card_style)
                                PosterTab.EFFECTS -> stringResource(Res.string.poster_tab_effects)
                                PosterTab.STICKERS -> stringResource(Res.string.poster_tab_stickers)
                            }
                        FilterChip(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            label = { Text(label) },
                        )
                    }
                }

                when (selectedTab) {
                    PosterTab.PHOTO -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { photoPicker.launch("image/*") }) {
                                Text(stringResource(Res.string.poster_choose_photo))
                            }
                            OutlinedButton(onClick = { backgroundUri = null; photoScale = 1f; photoOffsetX = 0f; photoOffsetY = 0f }) {
                                Text(stringResource(Res.string.poster_remove_photo))
                            }
                        }
                        PosterSlider(
                            label = stringResource(Res.string.poster_photo_size),
                            value = photoScale,
                            range = 0.5f..2f,
                            valueLabel = "${(photoScale * 100).roundToInt()}%",
                            onValueChange = { photoScale = it },
                        )
                        PosterSlider(
                            label = stringResource(Res.string.poster_photo_horizontal),
                            value = photoOffsetX,
                            range = -100f..100f,
                            valueLabel = photoOffsetX.roundToInt().toString(),
                            onValueChange = { photoOffsetX = it },
                        )
                        PosterSlider(
                            label = stringResource(Res.string.poster_photo_vertical),
                            value = photoOffsetY,
                            range = -100f..100f,
                            valueLabel = photoOffsetY.roundToInt().toString(),
                            onValueChange = { photoOffsetY = it },
                        )
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { photoFit = PosterFit.FILL }) { Text(stringResource(Res.string.poster_fill_screen)) }
                            OutlinedButton(onClick = { photoFit = PosterFit.FIT }) { Text(stringResource(Res.string.poster_fit_all)) }
                            OutlinedButton(onClick = { photoRotation = (photoRotation + 90f) % 360f }) { Text(stringResource(Res.string.poster_rotate)) }
                            OutlinedButton(onClick = { photoMirrored = !photoMirrored }) { Text(stringResource(Res.string.poster_mirror)) }
                        }
                    }
                    PosterTab.CARD -> {
                        PosterSlider(
                            label = stringResource(Res.string.poster_card_size),
                            value = cardScale,
                            range = 0.55f..1.65f,
                            valueLabel = "${(cardScale * 100).roundToInt()}%",
                            onValueChange = { cardScale = it },
                        )
                        PosterSlider(
                            label = stringResource(Res.string.poster_card_opacity),
                            value = cardOpacity,
                            range = 0.35f..1f,
                            valueLabel = "${(cardOpacity * 100).roundToInt()}%",
                            onValueChange = { cardOpacity = it },
                        )
                        OutlinedButton(onClick = { cardOffsetX = 0f; cardOffsetY = 0f; cardScale = 1f; cardRotation = 0f }) {
                            Text(stringResource(Res.string.poster_reset_position))
                        }
                        Text(
                            text = stringResource(Res.string.poster_tab_card) + " · " + title,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    PosterTab.STYLE -> {
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PosterStyleChip(PosterCardStyle.MINIMAL, cardStyle, stringResource(Res.string.poster_style_minimal)) { cardStyle = it }
                            PosterStyleChip(PosterCardStyle.DARK, cardStyle, stringResource(Res.string.poster_style_dark)) { cardStyle = it }
                            PosterStyleChip(PosterCardStyle.LIGHT, cardStyle, stringResource(Res.string.poster_style_light)) { cardStyle = it }
                            PosterStyleChip(PosterCardStyle.RETRO, cardStyle, stringResource(Res.string.poster_style_retro)) { cardStyle = it }
                        }
                    }
                    PosterTab.EFFECTS -> {
                        FilterChip(selected = vignetteEnabled, onClick = { vignetteEnabled = !vignetteEnabled }, label = { Text(stringResource(Res.string.poster_effect_vignette)) })
                        FilterChip(selected = sparkleEnabled, onClick = { sparkleEnabled = !sparkleEnabled }, label = { Text(stringResource(Res.string.poster_effect_sparkle)) })
                        FilterChip(selected = grainEnabled, onClick = { grainEnabled = !grainEnabled }, label = { Text(stringResource(Res.string.poster_effect_grain)) })
                    }
                    PosterTab.STICKERS -> {
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = selectedSticker == "★", onClick = { selectedSticker = if (selectedSticker == "★") null else "★" }, label = { Text(stringResource(Res.string.poster_sticker_star)) })
                            FilterChip(selected = selectedSticker == "♥", onClick = { selectedSticker = if (selectedSticker == "♥") null else "♥" }, label = { Text(stringResource(Res.string.poster_sticker_heart)) })
                            FilterChip(selected = selectedSticker == "♫", onClick = { selectedSticker = if (selectedSticker == "♫") null else "♫" }, label = { Text(stringResource(Res.string.poster_sticker_music)) })
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(onClick = onDismiss, enabled = !busy, modifier = Modifier.weight(1f)) {
                        Text(stringResource(Res.string.back))
                    }
                    OutlinedButton(
                        onClick = { exportPoster(saveToGallery = false) },
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(stringResource(Res.string.poster_share))
                    }
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED
                            ) {
                                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            } else {
                                exportPoster(saveToGallery = true)
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text(stringResource(Res.string.poster_save))
                    }
                }
                if (busy) {
                    Text(
                        text = stringResource(Res.string.poster_rendering),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun PosterSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    onValueChange: (Float) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(valueLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}

@Composable
private fun PosterStyleChip(
    style: PosterCardStyle,
    selected: PosterCardStyle,
    label: String,
    onSelect: (PosterCardStyle) -> Unit,
) {
    FilterChip(selected = selected == style, onClick = { onSelect(style) }, label = { Text(label) })
}

private fun cardContainerColor(style: PosterCardStyle): Color =
    when (style) {
        PosterCardStyle.MINIMAL -> Color(0xCC252535)
        PosterCardStyle.DARK -> Color(0xF0181822)
        PosterCardStyle.LIGHT -> Color(0xEAF3F0F8)
        PosterCardStyle.RETRO -> Color(0xFFF0D9B5)
    }

private fun cardContentColor(style: PosterCardStyle): Color =
    if (style == PosterCardStyle.LIGHT || style == PosterCardStyle.RETRO) Color(0xFF1D1B24) else Color.White

private data class PosterRenderConfig(
    val backgroundUri: Uri?,
    val fallbackArtworkUrl: String?,
    val title: String,
    val artist: String,
    val lyrics: String,
    val photoScale: Float,
    val photoOffsetX: Float,
    val photoOffsetY: Float,
    val photoRotation: Float,
    val photoMirrored: Boolean,
    val photoFit: PosterFit,
    val cardScale: Float,
    val cardOpacity: Float,
    val cardOffsetX: Float,
    val cardOffsetY: Float,
    val cardRotation: Float,
    val cardStyle: PosterCardStyle,
    val vignetteEnabled: Boolean,
    val sparkleEnabled: Boolean,
    val grainEnabled: Boolean,
    val sticker: String?,
)

private suspend fun renderSongPoster(context: Context, config: PosterRenderConfig): Bitmap =
    withContext(Dispatchers.IO) {
        val width = 1080
        val height = 1920
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawColor(android.graphics.Color.rgb(20, 20, 32))

        val background = loadPosterImage(context, config.backgroundUri ?: config.fallbackArtworkUrl)
        if (background != null) {
            val fitScale =
                if (config.photoFit == PosterFit.FILL) {
                    max(width.toFloat() / background.width, height.toFloat() / background.height)
                } else {
                    min(width.toFloat() / background.width, height.toFloat() / background.height)
                }
            val drawWidth = background.width * fitScale * config.photoScale
            val drawHeight = background.height * fitScale * config.photoScale
            val centerX = width / 2f + config.photoOffsetX / 100f * width
            val centerY = height / 2f + config.photoOffsetY / 100f * height
            val destination = RectF(
                centerX - drawWidth / 2f,
                centerY - drawHeight / 2f,
                centerX + drawWidth / 2f,
                centerY + drawHeight / 2f,
            )
            canvas.save()
            canvas.rotate(config.photoRotation, centerX, centerY)
            if (config.photoMirrored) canvas.scale(-1f, 1f, centerX, centerY)
            canvas.drawBitmap(background, null, destination, paint)
            canvas.restore()
            background.recycle()
        } else {
            paint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), intArrayOf(0xFF40466C.toInt(), 0xFF171724.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            paint.shader = null
        }

        paint.color = 0x40000000
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        if (config.vignetteEnabled) {
            paint.shader = android.graphics.RadialGradient(
                width / 2f,
                height / 2f,
                max(width, height) * 0.72f,
                intArrayOf(0x00000000, 0x88000000.toInt()),
                floatArrayOf(0.38f, 1f),
                Shader.TileMode.CLAMP,
            )
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            paint.shader = null
        }

        if (config.sparkleEnabled) {
            paint.color = android.graphics.Color.WHITE
            paint.alpha = 225
            paint.textSize = 72f
            canvas.drawText("✦", 820f, 260f, paint)
            canvas.drawText("✧", 190f, 510f, paint)
            canvas.drawText("✦", 870f, 1000f, paint)
            paint.alpha = 255
        }
        if (config.grainEnabled) {
            paint.shader = null
            paint.color = android.graphics.Color.WHITE
            paint.alpha = 16
            for (index in 0 until 900) {
                val x = ((index * 7919L) % width).toFloat()
                val y = ((index * 104729L) % height).toFloat()
                canvas.drawPoint(x, y, paint)
            }
            paint.alpha = 255
        }

        val cardWidth = 900f * config.cardScale
        val cardHeight = 340f * config.cardScale
        val centerX = width / 2f + config.cardOffsetX * width
        val centerY = height / 2f + config.cardOffsetY * height
        val card = RectF(centerX - cardWidth / 2f, centerY - cardHeight / 2f, centerX + cardWidth / 2f, centerY + cardHeight / 2f)
        val cardColor =
            when (config.cardStyle) {
                PosterCardStyle.MINIMAL -> 0xD9252535.toInt()
                PosterCardStyle.DARK -> 0xF0181822.toInt()
                PosterCardStyle.LIGHT -> 0xEAF3F0F8.toInt()
                PosterCardStyle.RETRO -> 0xFFF0D9B5.toInt()
            }
        val textColor = if (config.cardStyle == PosterCardStyle.LIGHT || config.cardStyle == PosterCardStyle.RETRO) 0xFF1D1B24.toInt() else android.graphics.Color.WHITE
        paint.color = cardColor
        paint.alpha = (config.cardOpacity * 255f).roundToInt().coerceIn(0, 255)
        canvas.save()
        canvas.rotate(config.cardRotation, centerX, centerY)
        canvas.drawRoundRect(card, 56f * config.cardScale, 56f * config.cardScale, paint)
        paint.alpha = 255

        val artwork = loadPosterImage(context, config.fallbackArtworkUrl)
        val cover = RectF(card.left + 38f * config.cardScale, card.top + 42f * config.cardScale, card.left + 260f * config.cardScale, card.bottom - 42f * config.cardScale)
        if (artwork != null) {
            drawRoundedBitmap(canvas, artwork, cover, 28f * config.cardScale, paint)
            artwork.recycle()
        } else {
            paint.color = 0xFF6657C8.toInt()
            canvas.drawRoundRect(cover, 28f * config.cardScale, 28f * config.cardScale, paint)
            paint.color = android.graphics.Color.WHITE
            paint.textSize = 86f * config.cardScale
            paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            canvas.drawText("♫", cover.left + 70f * config.cardScale, cover.centerY() + 28f * config.cardScale, paint)
        }

        paint.color = textColor
        paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        paint.textSize = 48f * config.cardScale
        canvas.drawText(fitPosterText(config.title, paint, card.width() - 340f * config.cardScale), cover.right + 34f * config.cardScale, card.top + 100f * config.cardScale, paint)
        paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        paint.alpha = 205
        paint.textSize = 36f * config.cardScale
        canvas.drawText(fitPosterText(config.artist, paint, card.width() - 340f * config.cardScale), cover.right + 34f * config.cardScale, card.top + 154f * config.cardScale, paint)
        paint.textSize = 29f * config.cardScale
        val lyric = config.lyrics.lineSequence().firstOrNull()?.takeIf(String::isNotBlank).orEmpty()
        if (lyric.isNotBlank()) {
            canvas.drawText(fitPosterText(lyric, paint, card.width() - 340f * config.cardScale), cover.right + 34f * config.cardScale, card.top + 205f * config.cardScale, paint)
        }
        paint.alpha = 255
        paint.color = textColor
        paint.strokeWidth = 6f * config.cardScale
        canvas.drawLine(cover.right + 34f * config.cardScale, card.bottom - 85f * config.cardScale, card.right - 44f * config.cardScale, card.bottom - 85f * config.cardScale, paint.apply { alpha = 70 })
        canvas.drawLine(cover.right + 34f * config.cardScale, card.bottom - 85f * config.cardScale, cover.right + 285f * config.cardScale, card.bottom - 85f * config.cardScale, paint.apply { alpha = 235 })
        paint.alpha = 255
        paint.textSize = 38f * config.cardScale
        canvas.drawText("♫", cover.right + 34f * config.cardScale, card.bottom - 27f * config.cardScale, paint)
        canvas.drawText("Ⅱ", card.right - 84f * config.cardScale, card.bottom - 25f * config.cardScale, paint)
        canvas.restore()

        config.sticker?.let { sticker ->
            paint.color = android.graphics.Color.WHITE
            paint.textSize = 120f
            paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            canvas.drawText(sticker, 78f, 200f, paint)
        }
        paint.color = 0xCCFFFFFF.toInt()
        paint.textSize = 30f
        paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Y M O R", width / 2f, height - 68f, paint)
        output
    }

private suspend fun loadPosterImage(context: Context, model: Any?): Bitmap? {
    if (model == null) return null
    return try {
        val request =
            ImageRequest
                .Builder(context)
                .data(model)
                .size(1440, 1920)
                .allowHardware(false)
                .build()
        val result = context.imageLoader.execute(request) as? SuccessResult ?: return null
        result.image.toBitmap()
    } catch (error: CancellationException) {
        throw error
    } catch (_: Exception) {
        null
    }
}

private fun drawRoundedBitmap(
    canvas: Canvas,
    bitmap: Bitmap,
    bounds: RectF,
    radius: Float,
    paint: Paint,
) {
    val save = canvas.save()
    val path = Path().apply { addRoundRect(bounds, radius, radius, Path.Direction.CW) }
    canvas.clipPath(path)
    val scale = max(bounds.width() / bitmap.width, bounds.height() / bitmap.height)
    val width = bitmap.width * scale
    val height = bitmap.height * scale
    val destination = RectF(bounds.centerX() - width / 2f, bounds.centerY() - height / 2f, bounds.centerX() + width / 2f, bounds.centerY() + height / 2f)
    canvas.drawBitmap(bitmap, null, destination, paint)
    canvas.restoreToCount(save)
}

private fun fitPosterText(
    text: String,
    paint: Paint,
    maxWidth: Float,
): String {
    var result = text.replace('\n', ' ').trim()
    while (result.isNotEmpty() && paint.measureText(result) > maxWidth) result = result.dropLast(1)
    return if (result.length < text.trim().length) result.trimEnd() + "…" else result
}

private suspend fun savePosterToGallery(context: Context, bitmap: Bitmap) =
    withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val fileName = "Ymor_Poster_${System.currentTimeMillis()}.png"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values =
                ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Ymor")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            val uri = requireNotNull(resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values))
            try {
                requireNotNull(resolver.openOutputStream(uri, "w")).use { output ->
                    check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
                }
                val published = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(uri, published, null, null)
            } catch (error: Exception) {
                resolver.delete(uri, null, null)
                throw error
            }
        } else {
            val directory = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Ymor")
            check(directory.mkdirs() || directory.isDirectory)
            val file = File(directory, fileName)
            FileOutputStream(file).use { output -> check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) }
            MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
        }
    }

private suspend fun sharePosterBitmap(
    context: Context,
    bitmap: Bitmap,
    chooserTitle: String,
) = withContext(Dispatchers.IO) {
    val directory = File(context.cacheDir, "images").apply { check(mkdirs() || isDirectory) }
    val file = File(directory, "ymor_poster_${System.currentTimeMillis()}.png")
    FileOutputStream(file).use { output -> check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent =
        Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newUri(context.contentResolver, chooserTitle, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    withContext(Dispatchers.Main) {
        context.startActivity(Intent.createChooser(intent, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
