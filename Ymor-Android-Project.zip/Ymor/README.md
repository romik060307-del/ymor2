# Ymor

**Ymor** is an Android music player built from a modified open-source music-player codebase. The first release focuses on a clean white-and-gold interface, softly rounded glass-inspired controls, album-art blur, and a lightweight default presentation.

## Included features

- YouTube Music search and playback (with or without signing in)
- Local playlists, listening history, queue, album and artist pages
- Offline downloads supported by the underlying player and its service terms
- Synchronized lyrics, translation and romanization
- Equalizer, bass/audio controls, playback speed and pitch
- Playlist cover editing and image selection
- Blurred artwork player background and compact floating mini-player
- Listen Together, music recognition, casting and media controls

Some online features depend on external services and may change when those services change. Ymor does not include music files or grant rights to copyrighted recordings.

## Build the APK with GitHub Actions

1. Create a GitHub repository and upload this project (or a single ZIP of it together with the `.github` folder; the workflow unpacks the ZIP itself).
2. The **Build Ymor APK** workflow starts automatically on every push to the main branch (**Actions → Build Ymor APK → Run workflow** also works).
3. When the run is green, download the **Ymor-Android-APK** artifact.
4. Extract the artifact ZIP; install `Ymor.apk` on Android.

The workflow builds the debug variant, which is installable. Because the debug signing key is generated fresh on each run, uninstall the previous test build before installing a newly built APK if Android reports a signature conflict.

## Compatibility

Minimum Android version: Android 7.0 (API 24).

## Licensing and upstream notices

Ymor contains modifications to code originally distributed under **GNU GPL version 3.0**. The original `LICENSE` is retained. See [`UPSTREAM_NOTICES.md`](UPSTREAM_NOTICES.md) for the upstream project and notices. When redistributing Ymor or modified binaries, comply with GPL-3.0, including providing the corresponding source code and retaining required notices.
